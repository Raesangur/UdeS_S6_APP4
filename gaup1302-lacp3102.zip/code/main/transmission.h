void transmission_task(void* pvParameter);
void add_error_to_message();
