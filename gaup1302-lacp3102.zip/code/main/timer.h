#pragma once

#include "globaldef.h"

void setup_timer(uint32_t);
