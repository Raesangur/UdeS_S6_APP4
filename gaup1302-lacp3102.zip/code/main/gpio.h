void setup_gpio();
void set_tx_gpio();
void clear_tx_gpio();
bool read_rx_gpio();
